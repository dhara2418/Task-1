// ===================== STORAGE =====================
let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

// ===================== ELEMENTS =====================
const incomeEl = document.getElementById("income");
const expenseEl = document.getElementById("expense");
const balanceEl = document.getElementById("balance");
const list = document.getElementById("transactionList");

const dashboardSection = document.getElementById("dashboardSection");
const transactionsSection = document.getElementById("transactionsSection");

let barChart, pieChart;

// ===================== SIDEBAR FUNCTIONS =====================
function showDashboard() {
  dashboardSection.style.display = "block";
  transactionsSection.style.display = "block";
}

function showTransactions() {
  dashboardSection.style.display = "none";
  transactionsSection.style.display = "block";
}

function showBudget() {
  dashboardSection.style.display = "none";
  transactionsSection.style.display = "none";
  alert("Budget section coming soon 🚀");
}

// ===================== ADD TRANSACTION =====================
function addTransaction() {
  const title = document.getElementById("title").value;
  const amount = +document.getElementById("amount").value;
  const type = document.getElementById("type").value;
  const category = document.getElementById("category").value;
  const date = document.getElementById("date").value;

  if (!title || !amount || !date) {
    alert("Please fill all fields");
    return;
  }

  transactions.push({ title, amount, type, category, date });
  localStorage.setItem("transactions", JSON.stringify(transactions));

  document.getElementById("title").value = "";
  document.getElementById("amount").value = "";

  render();
}

// ===================== DELETE =====================
function deleteTransaction(index) {
  transactions.splice(index, 1);
  localStorage.setItem("transactions", JSON.stringify(transactions));
  render();
}

// ===================== RENDER =====================
function render() {
  list.innerHTML = "";

  let income = 0;
  let expense = 0;
  let categoryData = {};

  transactions.forEach((t, i) => {
    if (t.type === "income") {
      income += t.amount;
    } else {
      expense += t.amount;
      categoryData[t.category] =
        (categoryData[t.category] || 0) + t.amount;
    }

    list.innerHTML += `
      <tr>
        <td>${t.title}</td>
        <td>${t.type}</td>
        <td>${t.category}</td>
        <td>${t.date}</td>
        <td>₹${t.amount}</td>
        <td>
          <button class="btn btn-danger btn-sm"
            onclick="deleteTransaction(${i})">
            Delete
          </button>
        </td>
      </tr>
    `;
  });

  incomeEl.innerText = `₹${income}`;
  expenseEl.innerText = `₹${expense}`;
  balanceEl.innerText = `₹${income - expense}`;

  updateCharts(income, expense, categoryData);
}

// ===================== CHARTS =====================
function updateCharts(income, expense, categoryData) {
  if (barChart) barChart.destroy();
  if (pieChart) pieChart.destroy();

  barChart = new Chart(document.getElementById("barChart"), {
    type: "bar",
    data: {
      labels: ["Income", "Expense"],
      datasets: [
        {
          data: [income, expense],
          backgroundColor: ["#0b7538", "#e74c3c"],
        },
      ],
    },
    options: {
      responsive: true,
    },
  });

  pieChart = new Chart(document.getElementById("pieChart"), {
    type: "pie",
    data: {
      labels: Object.keys(categoryData),
      datasets: [
        {
          data: Object.values(categoryData),
          backgroundColor: [
            "#0b7538",
            "#3498db",
            "#e74c3c",
            "#9b59b6",
          ],
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: "bottom",
        },
      },
    },
  });
}

// ===================== DEFAULT LOAD =====================
showDashboard();
render();
